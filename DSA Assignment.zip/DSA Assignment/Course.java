import java.util.*;

public class Course {
    private String courseCode;
    private String courseName;
    private int capacity;
    private Queue<String> waitingList;

    public Course(String courseCode, String courseName, int capacity) {
        this.courseCode = courseCode;
        this.courseName = courseName;
        this.capacity = capacity;
        this.waitingList = new LinkedList<>();
    }

    public String getCourseCode() { return courseCode; }
    public String getCourseName() { return courseName; }
    public int getCapacity() { return capacity; }
    public Queue<String> getWaitingList() { return waitingList; }

    public boolean addToWaitingList(String studentId) {
        if (waitingList.size() < capacity * 2) {
            waitingList.offer(studentId);
            return true;
        }
        return false;
    }

    public String getNextInLine() {
        return waitingList.poll();
    }

    public int getWaitingListSize() {
        return waitingList.size();
    }

    @Override
    public String toString() {
        return String.format("Course{Code: %s, Name: %s, Capacity: %d, Waiting: %d}",
                           courseCode, courseName, capacity, waitingList.size());
    }
}