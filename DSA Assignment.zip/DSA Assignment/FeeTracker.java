import java.util.*;

public class FeeTracker {
    // AVL Tree Node as inner class
    class AVLNode {
        FeeRecord record;
        AVLNode left, right;
        int height;

        AVLNode(FeeRecord record) {
            this.record = record;
            this.height = 1;
        }
    }

    private AVLNode root;
    private Map<String, List<FeeRecord>> studentFeeRecords;

    public FeeTracker() {
        this.root = null;
        this.studentFeeRecords = new HashMap<>();
    }

    // Public method to add fee record
    public void addFeeRecord(FeeRecord record) {
        root = insert(root, record);
        
        // Also maintain hash map for quick student-based lookups
        String studentId = record.getStudentId();
        if (!studentFeeRecords.containsKey(studentId)) {
            studentFeeRecords.put(studentId, new ArrayList<>());
        }
        studentFeeRecords.get(studentId).add(record);
        
        System.out.println("Fee record added for student: " + studentId);
    }

    // AVL Tree operations
    private int height(AVLNode node) {
        return node == null ? 0 : node.height;
    }

    private int getBalance(AVLNode node) {
        if (node == null) return 0;
        return height(node.left) - height(node.right);
    }

    private AVLNode rightRotate(AVLNode y) {
        AVLNode x = y.left;
        AVLNode T2 = x.right;

        x.right = y;
        y.left = T2;

        y.height = Math.max(height(y.left), height(y.right)) + 1;
        x.height = Math.max(height(x.left), height(x.right)) + 1;

        return x;
    }

    private AVLNode leftRotate(AVLNode x) {
        AVLNode y = x.right;
        AVLNode T2 = y.left;

        y.left = x;
        x.right = T2;

        x.height = Math.max(height(x.left), height(x.right)) + 1;
        y.height = Math.max(height(y.left), height(y.right)) + 1;

        return y;
    }

    private AVLNode insert(AVLNode node, FeeRecord record) {
        if (node == null) {
            return new AVLNode(record);
        }

        if (record.compareTo(node.record) < 0) {
            node.left = insert(node.left, record);
        } else if (record.compareTo(node.record) > 0) {
            node.right = insert(node.right, record);
        } else {
            return node; // Duplicate records not allowed
        }

        // Update height
        node.height = 1 + Math.max(height(node.left), height(node.right));

        // Get balance factor
        int balance = getBalance(node);

        // Left Left Case
        if (balance > 1 && record.compareTo(node.left.record) < 0) {
            return rightRotate(node);
        }

        // Right Right Case
        if (balance < -1 && record.compareTo(node.right.record) > 0) {
            return leftRotate(node);
        }

        // Left Right Case
        if (balance > 1 && record.compareTo(node.left.record) > 0) {
            node.left = leftRotate(node.left);
            return rightRotate(node);
        }

        // Right Left Case
        if (balance < -1 && record.compareTo(node.right.record) < 0) {
            node.right = rightRotate(node.right);
            return leftRotate(node);
        }

        return node;
    }

    // Display all fee records in sorted order (by date)
    public void displayAllFeeRecords() {
        System.out.println("\n=== ALL FEE RECORDS (Sorted by Date) ===");
        if (root == null) {
            System.out.println("No fee records found.");
            return;
        }
        inOrderTraversal(root);
    }

    private void inOrderTraversal(AVLNode node) {
        if (node != null) {
            inOrderTraversal(node.left);
            System.out.println(node.record);
            inOrderTraversal(node.right);
        }
    }

    // Get fee records for a specific student
    public List<FeeRecord> getStudentFeeRecords(String studentId) {
        return studentFeeRecords.getOrDefault(studentId, new ArrayList<>());
    }

    // Display fee records for a specific student
    public void displayStudentFeeRecords(String studentId) {
        List<FeeRecord> records = getStudentFeeRecords(studentId);
        System.out.println("\n=== FEE RECORDS FOR STUDENT " + studentId + " ===");
        if (records.isEmpty()) {
            System.out.println("No fee records found.");
        } else {
            for (FeeRecord record : records) {
                System.out.println(record);
            }
            double total = records.stream().mapToDouble(FeeRecord::getAmount).sum();
            System.out.printf("Total Paid: $%.2f\n", total);
        }
    }

    // Calculate total fees collected
    public double getTotalFeesCollected() {
        return calculateTotalFees(root);
    }

    private double calculateTotalFees(AVLNode node) {
        if (node == null) return 0;
        return node.record.getAmount() + 
               calculateTotalFees(node.left) + 
               calculateTotalFees(node.right);
    }

    // Generate fee clearance report
    public void generateFeeClearanceReport() {
        System.out.println("\n=== FEE CLEARANCE REPORT ===");
        System.out.printf("Total Fees Collected: $%.2f\n", getTotalFeesCollected());
        System.out.println("Number of Students with Fee Records: " + studentFeeRecords.size());
        
        for (String studentId : studentFeeRecords.keySet()) {
            List<FeeRecord> records = studentFeeRecords.get(studentId);
            double totalPaid = records.stream().mapToDouble(FeeRecord::getAmount).sum();
            System.out.printf("Student %s: Total Paid = $%.2f, Records = %d\n", 
                            studentId, totalPaid, records.size());
        }
    }
}