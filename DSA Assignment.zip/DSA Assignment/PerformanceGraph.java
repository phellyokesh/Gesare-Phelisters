// PerformanceGraph.java
import java.util.*;

public class PerformanceAnalytics {
    private Map<String, Map<String, Double>> performanceGraph; // Adjacency list: Student -> (Course -> Grade)
    private PriorityQueue<Map.Entry<String, Double>> topPerformers;

    public PerformanceAnalytics() {
        this.performanceGraph = new HashMap<>();
        // Max heap for top performers
        this.topPerformers = new PriorityQueue<>(
            (a, b) -> Double.compare(b.getValue(), a.getValue())
        );
    }

    public void addGrade(String studentId, String course, double grade) {
        performanceGraph.computeIfAbsent(studentId, k -> new HashMap<>())
                       .put(course, grade);
        updateTopPerformers();
    }

    private void updateTopPerformers() {
        topPerformers.clear();
        Map<String, Double> averages = new HashMap<>();

        // Calculate average grades for each student
        for (Map.Entry<String, Map<String, Double>> entry : performanceGraph.entrySet()) {
            String studentId = entry.getKey();
            Map<String, Double> grades = entry.getValue();
            
            double average = grades.values().stream()
                                 .mapToDouble(Double::doubleValue)
                                 .average()
                                 .orElse(0.0);
            averages.put(studentId, average);
        }

        // Add to priority queue
        topPerformers.addAll(averages.entrySet());
    }

    public void displayTopPerformers(int n) {
        System.out.println("\n=== TOP " + n + " PERFORMERS ===");
        PriorityQueue<Map.Entry<String, Double>> temp = new PriorityQueue<>(topPerformers);
        
        for (int i = 0; i < n && !temp.isEmpty(); i++) {
            Map.Entry<String, Double> entry = temp.poll();
            System.out.printf("Rank %d: Student %s - Average: %.2f\n", 
                            i + 1, entry.getKey(), entry.getValue());
        }
    }

    public void displayStudentPerformance(String studentId) {
        Map<String, Double> grades = performanceGraph.get(studentId);
        if (grades == null) {
            System.out.println("No performance data for student: " + studentId);
            return;
        }

        System.out.println("\n=== PERFORMANCE FOR STUDENT " + studentId + " ===");
        double average = grades.values().stream()
                             .mapToDouble(Double::doubleValue)
                             .average()
                             .orElse(0.0);
        
        for (Map.Entry<String, Double> entry : grades.entrySet()) {
            System.out.printf("Course: %s - Grade: %.2f\n", entry.getKey(), entry.getValue());
        }
        System.out.printf("Overall Average: %.2f\n", average);
    }

    public void displayCourseStatistics(String course) {
        List<Double> grades = new ArrayList<>();
        for (Map<String, Double> studentGrades : performanceGraph.values()) {
            if (studentGrades.containsKey(course)) {
                grades.add(studentGrades.get(course));
            }
        }

        if (grades.isEmpty()) {
            System.out.println("No data for course: " + course);
            return;
        }

        double average = grades.stream().mapToDouble(Double::doubleValue).average().orElse(0.0);
        double max = grades.stream().mapToDouble(Double::doubleValue).max().orElse(0.0);
        double min = grades.stream().mapToDouble(Double::doubleValue).min().orElse(0.0);

        System.out.printf("\n=== STATISTICS FOR COURSE %s ===\n", course);
        System.out.printf("Average: %.2f, Highest: %.2f, Lowest: %.2f, Students: %d\n",
                         average, max, min, grades.size());
    }
}