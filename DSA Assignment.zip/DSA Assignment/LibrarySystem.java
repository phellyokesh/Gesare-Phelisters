import java.util.*;

public class LibrarySystem {
    private Map<String, Book> bookCatalog;
    private Map<String, Stack<BorrowRecord>> studentBorrowHistory;
    private Map<String, BorrowRecord> currentBorrows;

    public LibrarySystem() {
        this.bookCatalog = new HashMap<>();
        this.studentBorrowHistory = new HashMap<>();
        this.currentBorrows = new HashMap<>();
    }

    public void addBook(Book book) {
        bookCatalog.put(book.getIsbn(), book);
    }

    public boolean borrowBook(String isbn, String studentId) {
        Book book = bookCatalog.get(isbn);
        if (book == null) {
            System.out.println("Book not found: " + isbn);
            return false;
        }

        if (!book.borrowBook()) {
            System.out.println("No copies available for: " + book.getTitle());
            return false;
        }

        BorrowRecord record = new BorrowRecord(isbn, studentId, new Date());
        String key = studentId + ":" + isbn;
        currentBorrows.put(key, record);

        studentBorrowHistory.computeIfAbsent(studentId, k -> new Stack<>())
                           .push(record);

        System.out.println("Book borrowed: " + book.getTitle() + " by Student " + studentId);
        return true;
    }

    public boolean returnBook(String isbn, String studentId) {
        String key = studentId + ":" + isbn;
        BorrowRecord record = currentBorrows.get(key);
        
        if (record == null) {
            System.out.println("No active borrow record found");
            return false;
        }

        Book book = bookCatalog.get(isbn);
        if (book != null) {
            book.returnBook();
            record.setReturnDate(new Date());
            currentBorrows.remove(key);
            System.out.println("Book returned: " + book.getTitle());
            return true;
        }
        return false;
    }

    public Book searchBook(String isbn) {
        return bookCatalog.get(isbn);
    }

    public void displayAvailableBooks() {
        System.out.println("\n=== AVAILABLE BOOKS ===");
        for (Book book : bookCatalog.values()) {
            if (book.getAvailableCopies() > 0) {
                System.out.println(book);
            }
        }
    }

    public void displayStudentBorrowHistory(String studentId) {
        Stack<BorrowRecord> history = studentBorrowHistory.get(studentId);
        if (history == null || history.isEmpty()) {
            System.out.println("No borrow history for student: " + studentId);
            return;
        }

        System.out.println("\n=== BORROW HISTORY FOR STUDENT " + studentId + " ===");
        List<BorrowRecord> temp = new ArrayList<>(history);
        Collections.reverse(temp);
        for (BorrowRecord record : temp) {
            System.out.println("ISBN: " + record.getIsbn() + 
                             ", Borrowed: " + record.getBorrowDate() +
                             ", Returned: " + (record.getReturnDate() != null ? record.getReturnDate() : "Not returned"));
        }
    }
}