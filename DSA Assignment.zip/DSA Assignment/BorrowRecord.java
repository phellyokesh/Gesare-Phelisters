import java.util.Date;

public class BorrowRecord {
    private String isbn;
    private String studentId;
    private Date borrowDate;
    private Date returnDate;

    public BorrowRecord(String isbn, String studentId, Date borrowDate) {
        this.isbn = isbn;
        this.studentId = studentId;
        this.borrowDate = borrowDate;
    }

    public void setReturnDate(Date returnDate) {
        this.returnDate = returnDate;
    }

    public String getIsbn() { return isbn; }
    public String getStudentId() { return studentId; }
    public Date getBorrowDate() { return borrowDate; }
    public Date getReturnDate() { return returnDate; }
}