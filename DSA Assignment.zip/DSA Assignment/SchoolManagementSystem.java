// SchoolManagementSystem.java
import java.util.*;

public class SchoolManagementSystem {
    private StudentRegistry studentRegistry;
    private CourseScheduler courseScheduler;
    private FeeTracker feeTracker;
    private LibrarySystem librarySystem;
    private PerformanceAnalytics performanceAnalytics;

    public SchoolManagementSystem() {
        this.studentRegistry = new StudentRegistry();
        this.courseScheduler = new CourseScheduler();
        this.feeTracker = new FeeTracker();
        this.librarySystem = new LibrarySystem();
        this.performanceAnalytics = new PerformanceAnalytics();
        initializeSampleData();
    }

    private void initializeSampleData() {
        // Initialize with sample data
        studentRegistry.addStudent(new Student("S001", "John Doe", "Computer Science"));
        studentRegistry.addStudent(new Student("S002", "Jane Smith", "Mathematics"));
        studentRegistry.addStudent(new Student("S003", "Bob Johnson", "Physics"));
        
        courseScheduler.addCourse(new Course("CS101", "Introduction to Programming", 30));
        courseScheduler.addCourse(new Course("MATH201", "Calculus I", 25));
        
        librarySystem.addBook(new Book("B001", "Introduction to Algorithms", "Cormen", 5));
        librarySystem.addBook(new Book("B002", "Clean Code", "Martin", 3));
    }

    // Getters for modules
    public StudentRegistry getStudentRegistry() { return studentRegistry; }
    public CourseScheduler getCourseScheduler() { return courseScheduler; }
    public FeeTracker getFeeTracker() { return feeTracker; }
    public LibrarySystem getLibrarySystem() { return librarySystem; }
    public PerformanceAnalytics getPerformanceAnalytics() { return performanceAnalytics; }
}
