import java.util.*;

public class Student {
    private String studentId;
    private String name;
    private String department;
    private Map<String, Double> grades;

    public Student(String studentId, String name, String department) {
        this.studentId = studentId;
        this.name = name;
        this.department = department;
        this.grades = new HashMap<>();
    }

    public String getStudentId() { return studentId; }
    public String getName() { return name; }
    public String getDepartment() { return department; }
    public Map<String, Double> getGrades() { return grades; }

    public void addGrade(String course, double grade) {
        grades.put(course, grade);
    }

    @Override
    public String toString() {
        return String.format("Student{ID: %s, Name: %s, Department: %s}", 
                           studentId, name, department);
    }
}