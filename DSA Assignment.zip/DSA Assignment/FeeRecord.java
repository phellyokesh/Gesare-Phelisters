import java.util.Date;

public class FeeRecord implements Comparable<FeeRecord> {
    private String studentId;
    private double amount;
    private Date paymentDate;
    private String transactionId;

    public FeeRecord(String studentId, double amount, Date paymentDate, String transactionId) {
        this.studentId = studentId;
        this.amount = amount;
        this.paymentDate = paymentDate;
        this.transactionId = transactionId;
    }

    public String getStudentId() { return studentId; }
    public double getAmount() { return amount; }
    public Date getPaymentDate() { return paymentDate; }
    public String getTransactionId() { return transactionId; }

    @Override
    public int compareTo(FeeRecord other) {
        int dateCompare = this.paymentDate.compareTo(other.paymentDate);
        if (dateCompare != 0) return dateCompare;
        return this.transactionId.compareTo(other.transactionId);
    }

    @Override
    public String toString() {
        return String.format("FeeRecord{Student: %s, Amount: $%.2f, Date: %s}",
                           studentId, amount, paymentDate);
    }
}