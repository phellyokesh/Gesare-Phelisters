import java.util.*;

public class StudentRegistry {
    private Map<String, Student> students;

    public StudentRegistry() {
        this.students = new HashMap<>();
    }

    public void addStudent(Student student) {
        students.put(student.getStudentId(), student);
        System.out.println("Student added: " + student.getName());
    }

    public Student getStudent(String studentId) {
        return students.get(studentId);
    }

    public boolean removeStudent(String studentId) {
        Student removed = students.remove(studentId);
        if (removed != null) {
            System.out.println("Student removed: " + removed.getName());
            return true;
        }
        return false;
    }

    public void displayAllStudents() {
        System.out.println("\n=== ALL STUDENTS ===");
        for (Student student : students.values()) {
            System.out.println(student);
        }
    }

    public int getTotalStudents() {
        return students.size();
    }
}