import java.util.*;

public class CourseScheduler {
    private Map<String, Course> courses;
    private Map<String, Set<String>> studentEnrollments;

    public CourseScheduler() {
        this.courses = new HashMap<>();
        this.studentEnrollments = new HashMap<>();
    }

    public void addCourse(Course course) {
        courses.put(course.getCourseCode(), course);
    }

    public boolean enrollStudent(String studentId, String courseCode) {
        Course course = courses.get(courseCode);
        if (course == null) {
            System.out.println("Course not found: " + courseCode);
            return false;
        }

        Set<String> enrolledCourses = studentEnrollments.getOrDefault(studentId, new HashSet<>());
        if (enrolledCourses.contains(courseCode)) {
            System.out.println("Student already enrolled in course: " + courseCode);
            return true;
        }

        if (enrolledCourses.size() >= 5) {
            System.out.println("Student " + studentId + " has reached course limit");
            return false;
        }

        course.addToWaitingList(studentId);
        System.out.println("Student " + studentId + " added to waiting list for " + courseCode);
        processWaitingLists();
        return true;
    }

    private void processWaitingLists() {
        for (Course course : courses.values()) {
            while (studentEnrollments.values().stream()
                    .filter(enrolled -> enrolled.contains(course.getCourseCode()))
                    .count() < course.getCapacity() && 
                   !course.getWaitingList().isEmpty()) {
                
                String studentId = course.getNextInLine();
                if (studentId != null) {
                    studentEnrollments.computeIfAbsent(studentId, k -> new HashSet<>())
                                    .add(course.getCourseCode());
                    System.out.println("Student " + studentId + " enrolled in " + course.getCourseCode());
                }
            }
        }
    }

    public void displayCourseStatus() {
        System.out.println("\n=== COURSE STATUS ===");
        for (Course course : courses.values()) {
            long enrolledCount = studentEnrollments.values().stream()
                    .filter(enrolled -> enrolled.contains(course.getCourseCode()))
                    .count();
            System.out.println(course + " | Enrolled: " + enrolledCount);
        }
    }
}