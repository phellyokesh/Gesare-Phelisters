import java.util.Date;

public class MainApp {
    public static void main(String[] args) {
        SchoolManagementSystem sms = new SchoolManagementSystem();
        
        // Test Student Registry
        System.out.println("=== TESTING STUDENT REGISTRY ===");
        sms.getStudentRegistry().displayAllStudents();
        
        // Test Course Scheduling
        System.out.println("\n=== TESTING COURSE SCHEDULING ===");
        sms.getCourseScheduler().enrollStudent("S001", "CS101");
        sms.getCourseScheduler().enrollStudent("S002", "CS101");
        sms.getCourseScheduler().enrollStudent("S003", "CS101");
        sms.getCourseScheduler().displayCourseStatus();
        
        // Test Fee Tracking
        System.out.println("\n=== TESTING FEE TRACKING ===");
        sms.getFeeTracker().addFeeRecord(new FeeRecord("S001", 1500.0, new Date(), "T001"));
        sms.getFeeTracker().addFeeRecord(new FeeRecord("S002", 1200.0, new Date(System.currentTimeMillis() + 1000), "T002"));
        sms.getFeeTracker().displayAllFeeRecords();
        System.out.printf("Total fees collected: $%.2f\n", sms.getFeeTracker().getTotalFeesCollected());
        
        // Test Library System
        System.out.println("\n=== TESTING LIBRARY SYSTEM ===");
        sms.getLibrarySystem().borrowBook("B001", "S001");
        sms.getLibrarySystem().borrowBook("B002", "S001");
        sms.getLibrarySystem().displayAvailableBooks();
        sms.getLibrarySystem().displayStudentBorrowHistory("S001");
        
        // Test Performance Analytics - FIXED METHOD NAME
        System.out.println("\n=== TESTING PERFORMANCE ANALYTICS ===");
        sms.getPerformanceAnalytics().addGrade("S001", "CS101", 85.5); // FIXED: getPerformanceAnalytics()
        sms.getPerformanceAnalytics().addGrade("S001", "MATH201", 92.0);
        sms.getPerformanceAnalytics().addGrade("S002", "CS101", 78.0);
        sms.getPerformanceAnalytics().addGrade("S003", "CS101", 95.5);
        
        sms.getPerformanceAnalytics().displayTopPerformers(3);
        sms.getPerformanceAnalytics().displayStudentPerformance("S001");
        sms.getPerformanceAnalytics().displayCourseStatistics("CS101");
    }
}